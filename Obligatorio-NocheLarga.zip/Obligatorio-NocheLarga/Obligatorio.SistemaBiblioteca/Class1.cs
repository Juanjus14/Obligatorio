﻿using System;

namespace Obligatorio.SistemaBiblioteca
{
    public class Class1
    {
    }
}
