﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Obligatorio.LogicaNegocio.InterfacesEntidades
{
    public interface IValidacion
    {
        bool Validar();
    }
}
