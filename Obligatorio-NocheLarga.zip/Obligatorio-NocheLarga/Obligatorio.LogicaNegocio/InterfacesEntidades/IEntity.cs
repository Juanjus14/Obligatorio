﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Obligatorio.LogicaNegocio.InterfacesEntidades
{
    public interface IEntity
    {
        public int Id { get; set; }
    }
}
