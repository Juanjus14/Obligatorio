﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ObligatorioWebApi.DTOs
{
    public class PartidoDTO {
       
       public int selUnoId { get; set; }
       public int selDosId { get; set; }
        public DateTime FechaPartido { get; set; }
        public int HoraPartido { get; set; }
    }
}
