﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Obligatorio.LogicaNegocio.Enums;

namespace ObligatorioWebApi.DTOs
{
    public class PaisDTO
    {
        public string NombreMos { get; set; }
        public string CodigoISOMos { get; set; }
        public double PBIMos { get; set; }
        public int PoblacionMos { get; set; }
        public string ImagenMos { get; set; }
        public EnumeradosObligatorio.Regiones RegionMos { get; set; }


    }
}
