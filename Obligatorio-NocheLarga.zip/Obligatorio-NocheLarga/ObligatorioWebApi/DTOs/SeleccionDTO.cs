﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Obligatorio.LogicaNegocio.Enums;

namespace ObligatorioWebApi.DTOs
{
    public class SeleccionDTO
    {
        
        public int PaisIdMos { get; set; }
        public string ContactoNomMos { get; set; }
        public string ContactoEmMos { get; set; }
        public string ContactoTelMos { get; set; }
        public int CantidadApostadoresMos { get; set; }
        public int GrupoMos { get; set; }
        public int PuntuacionMos { get; set; }

    }
}
