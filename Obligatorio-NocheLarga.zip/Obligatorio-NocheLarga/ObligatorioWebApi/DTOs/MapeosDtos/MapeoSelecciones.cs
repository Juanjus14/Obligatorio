﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Obligatorio.LogicaNegocio.Entidades;

namespace ObligatorioWebApi.DTOs.MapeosDtos
{
    public class MapeoSelecciones
    {
        internal SeleccionDTO FromSeleccion(Seleccion seleccion)
        {
            return new SeleccionDTO
            {
                PaisIdMos = seleccion.PaisId,
                ContactoNomMos = seleccion.Contacto.Nombre,
                ContactoEmMos = seleccion.Contacto.Email,
                ContactoTelMos = seleccion.Contacto.Telefono,
                CantidadApostadoresMos = seleccion.CantidadApostadores,
                GrupoMos = (int)seleccion.Grupo,
                PuntuacionMos = seleccion.Puntuacion

            };

        }
    }
}
