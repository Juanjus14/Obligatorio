﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Obligatorio.LogicaNegocio.Entidades;

namespace ObligatorioWebApi.DTOs.MapeosDtos
{
    public class MapeoPartidos
    {
        internal PartidoDTO FromPartido (Partido partido)
        {
            return new PartidoDTO
            {
                selUnoId = partido.Infoselpar[0].SeleccionId,
                selDosId = partido.Infoselpar[1].SeleccionId,
                FechaPartido = partido.Fecha,
                HoraPartido = (int)partido.Hora
            };
        }
    }
}
