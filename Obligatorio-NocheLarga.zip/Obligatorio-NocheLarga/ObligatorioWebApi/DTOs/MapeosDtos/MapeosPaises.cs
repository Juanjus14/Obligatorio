﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Obligatorio.LogicaNegocio.Entidades;

namespace ObligatorioWebApi.DTOs.MapeosDtos
{
    public class MapeosPaises
    {

        internal PaisDTO FromPais(Pais unPais)
        {
            return new PaisDTO
            {
            NombreMos = unPais.Nombre.Nombre,
            CodigoISOMos = unPais.CodigoISO.CodigoISO_Alfa3,
            PBIMos = unPais.PBI,
            PoblacionMos = unPais.Poblacion,
            ImagenMos = unPais.Imagen.URL,
            RegionMos = unPais.Region


        };
    }
}
}
