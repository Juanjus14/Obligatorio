﻿using System;
using System.Collections.Generic;
using System.Text;
using Obligatorio.LogicaNegocio.InterfacesRepositorios;

namespace Obligatorio.LogicaAccesoDatos.RepositoriosTesting
{
    class RepositorioPartidos
    {
    }
}
